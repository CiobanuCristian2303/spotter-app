import { action } from "./_generated/server";
import { v } from "convex/values";
import { createOpenRouter } from "@openrouter/ai-sdk-provider";
import { generateText } from "ai";

const openrouter = createOpenRouter({
  apiKey: process.env.OPENROUTER_API_KEY,
});

export const importFromUrl = action({
  args: { url: v.string() },
  handler: async (ctx, args) => {
    try {
      // 1. Fetch HTML
      const response = await fetch(args.url);
      const html = await response.text();
      
      // 2. Clean HTML slightly to reduce tokens
      const body = html.match(/<body[^>]*>([\s\S]*)<\/body>/i)?.[1] || html;
      const cleanText = body.replace(/<script[^>]*>([\s\S]*)<\/script>/gi, '')
                            .replace(/<style[^>]*>([\s\S]*)<\/style>/gi, '')
                            .replace(/<[^>]+>/g, ' ')
                            .substring(0, 15000); // Limit context size

      // 3. AI Transformation
      const { text } = await generateText({
        model: openrouter("google/gemini-2.0-flash-001"), // Fast and good for extraction
        prompt: `You are a car listing data extractor for Spotter Romania. 
        Extract the following vehicle data from this webpage content and return it strictly as JSON.
        Language is Romanian. 
        
        Fields to extract:
        - make (brand)
        - model
        - year (number)
        - price (number, in EUR)
        - mileage (number, in KM)
        - hp (horsepower, number)
        - fuelType (Petrol, Diesel, Hybrid, Electric)
        - transmission (Manual, Automatic)
        - engineSize (number, cm3)
        - location (city)
        - description (full ad description)
        - vin (if present, 17 characters)
        
        Content:
        ${cleanText}
        
        Return ONLY valid JSON.`,
      });

      const data = JSON.parse(text.replace(/```json/g, '').replace(/```/g, '').trim());
      return data;
    } catch (error) {
      console.error("AI Import Error:", error);
      throw new Error("Failed to parse car data from URL");
    }
  },
});
