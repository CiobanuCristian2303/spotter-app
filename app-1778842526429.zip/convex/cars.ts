import { query, mutation } from "./_generated/server";
import { v } from "convex/values";

export const list = query({
  args: {
    make: v.optional(v.string()),
    model: v.optional(v.string()),
    minPrice: v.optional(v.number()),
    maxPrice: v.optional(v.number()),
    minYear: v.optional(v.number()),
    maxYear: v.optional(v.number()),
    minMileage: v.optional(v.number()),
    maxMileage: v.optional(v.number()),
    minHP: v.optional(v.number()),
    maxHP: v.optional(v.number()),
    fuelType: v.optional(v.string()),
    transmission: v.optional(v.string()),
    isNative: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    let q = ctx.db.query("cars");
    
    // In a real production app with many cars, we would use indexes for all these filters.
    // For the current scale, we collect and filter.
    let results = await q.order("desc").collect();

    results = results.filter(c => !c.isSold);

    if (args.make && args.make !== "All") {
      results = results.filter(c => c.make === args.make);
    }
    if (args.model) {
      results = results.filter(c => c.model.toLowerCase().includes(args.model!.toLowerCase()));
    }
    if (args.minPrice !== undefined) results = results.filter(c => c.price >= args.minPrice!);
    if (args.maxPrice !== undefined) results = results.filter(c => c.price <= args.maxPrice!);
    if (args.minYear !== undefined) results = results.filter(c => c.year >= args.minYear!);
    if (args.maxYear !== undefined) results = results.filter(c => c.year <= args.maxYear!);
    if (args.minMileage !== undefined) results = results.filter(c => c.mileage >= args.minMileage!);
    if (args.maxMileage !== undefined) results = results.filter(c => c.mileage <= args.maxMileage!);
    if (args.minHP !== undefined) results = results.filter(c => (c.hp || 0) >= args.minHP!);
    if (args.maxHP !== undefined) results = results.filter(c => (c.hp || 0) <= args.maxHP!);
    if (args.fuelType && args.fuelType !== "Any") results = results.filter(c => c.fuelType === args.fuelType);
    if (args.transmission && args.transmission !== "Any") results = results.filter(c => c.transmission === args.transmission);
    if (args.isNative !== undefined) results = results.filter(c => c.isNative === args.isNative);

    return results.sort((a, b) => (b.lastRefreshedAt || b._creationTime) - (a.lastRefreshedAt || a._creationTime)).slice(0, 50);
  },
});

export const getById = query({
  args: { id: v.id("cars") },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.id);
  },
});

export const incrementViews = mutation({
  args: { id: v.id("cars") },
  handler: async (ctx, args) => {
    const car = await ctx.db.get(args.id);
    if (car) {
      await ctx.db.patch(args.id, { views: (car.views || 0) + 1 });
    }
  },
});

export const incrementLeads = mutation({
  args: { id: v.id("cars") },
  handler: async (ctx, args) => {
    const car = await ctx.db.get(args.id);
    if (car) {
      await ctx.db.patch(args.id, { leads: (car.leads || 0) + 1 });
    }
  },
});

export const getDealerInventory = query({
  args: { userId: v.id("users") },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("cars")
      .withIndex("by_userId", (q) => q.eq("userId", args.userId))
      .order("desc")
      .collect();
  },
});

export const markAsSold = mutation({
  args: { id: v.id("cars") },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new Error("Unauthenticated");
    
    const car = await ctx.db.get(args.id);
    if (!car) throw new Error("Car not found");
    
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
      
    if (!user || car.userId !== user._id) {
      throw new Error("Unauthorized");
    }

    await ctx.db.patch(args.id, { isSold: true });
  },
});

export const refreshListing = mutation({
  args: { id: v.id("cars") },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new Error("Unauthenticated");
    
    const car = await ctx.db.get(args.id);
    if (!car) throw new Error("Car not found");
    
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
      
    if (!user || car.userId !== user._id) {
      throw new Error("Unauthorized");
    }

    await ctx.db.patch(args.id, { lastRefreshedAt: Date.now() });
  },
});

export const createNativeListing = mutation({
  args: {
    userId: v.optional(v.id("users")),
    make: v.string(),
    model: v.string(),
    year: v.number(),
    price: v.number(),
    currency: v.string(),
    mileage: v.number(),
    vin: v.optional(v.string()),
    location: v.string(),
    images: v.array(v.string()),
    description: v.string(),
    transmission: v.optional(v.string()),
    fuelType: v.optional(v.string()),
    engineSize: v.optional(v.number()),
    hp: v.optional(v.number()),
    sellerType: v.union(v.literal("private"), v.literal("dealer")),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new Error("Unauthenticated");

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();

    if (!user) throw new Error("User profile not found");

    return await ctx.db.insert("cars", {
      ...args,
      userId: user._id,
      sources: [{ platform: "Spotter", price: args.price }],
      isNative: true,
      views: 0,
      leads: 0,
      lastRefreshedAt: Date.now(),
    });
  },
});

export const ingestExternalListing = mutation({
  args: {
    make: v.string(),
    model: v.string(),
    year: v.number(),
    price: v.number(),
    currency: v.string(),
    mileage: v.number(),
    vin: v.optional(v.string()),
    location: v.string(),
    platform: v.string(),
    url: v.string(),
    images: v.array(v.string()),
    description: v.string(),
    sellerType: v.union(v.literal("private"), v.literal("dealer")),
  },
  handler: async (ctx, args) => {
    // This action would typically be called by an internal scraper service with a secret key or from a trusted background process.
    // We assume it's authorized for now.
    let existingCar = null;

    if (args.vin) {
      existingCar = await ctx.db
        .query("cars")
        .withIndex("by_vin", (q) => q.eq("vin", args.vin))
        .first();
    }

    if (!existingCar) {
      const potentials = await ctx.db
        .query("cars")
        .withIndex("by_make", (q) => q.eq("make", args.make))
        .collect();

      existingCar = potentials.find((c) => {
        const sameModel = c.model.toLowerCase() === args.model.toLowerCase();
        const sameYear = c.year === args.year;
        const mileageDiff = Math.abs(c.mileage - args.mileage) / c.mileage;
        return sameModel && sameYear && mileageDiff < 0.05;
      });
    }

    if (existingCar) {
      const sources = [...existingCar.sources];
      const platformExists = sources.findIndex((s) => s.platform === args.platform);

      if (platformExists > -1) {
        sources[platformExists] = { platform: args.platform, url: args.url, price: args.price };
      } else {
        sources.push({ platform: args.platform, url: args.url, price: args.price });
      }

      const bestPrice = Math.min(...sources.map((s) => s.price));
      const previousPrice = existingCar.price;

      const updateData: any = {
        sources,
        price: bestPrice,
      };

      if (bestPrice < previousPrice) {
        updateData.previousPrice = previousPrice;
        
        const watchers = await ctx.db
          .query("watchlist")
          .withIndex("by_car", (q) => q.eq("carId", existingCar!._id))
          .collect();

        for (const watch of watchers) {
          await ctx.db.insert("notifications", {
            userId: watch.userId,
            type: "price_drop",
            title: "🔥 Price Drop Alert!",
            body: `The ${existingCar!.make} ${existingCar!.model} you are watching just dropped to ${bestPrice.toLocaleString()} ${existingCar!.currency}!`,
            data: { carId: existingCar!._id },
            read: false,
            createdAt: Date.now(),
          });
        }
      }

      await ctx.db.patch(existingCar._id, updateData);
      return existingCar._id;
    } else {
      return await ctx.db.insert("cars", {
        make: args.make,
        model: args.model,
        year: args.year,
        price: args.price,
        currency: args.currency,
        mileage: args.mileage,
        vin: args.vin,
        location: args.location,
        sources: [{ platform: args.platform, url: args.url, price: args.price }],
        images: args.images,
        isNative: false,
        sellerType: args.sellerType,
        description: args.description,
        views: 0,
        leads: 0,
        lastRefreshedAt: Date.now(),
      });
    }
  },
});

export const toggleWatchlist = mutation({
  args: { userId: v.string(), carId: v.id("cars") },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new Error("Unauthenticated");

    const existing = await ctx.db
      .query("watchlist")
      .withIndex("by_user_car", (q) => q.eq("userId", identity.tokenIdentifier).eq("carId", args.carId))
      .unique();

    if (existing) {
      await ctx.db.delete(existing._id);
      return false;
    } else {
      await ctx.db.insert("watchlist", {
        userId: identity.tokenIdentifier,
        carId: args.carId,
        savedAt: Date.now(),
      });
      return true;
    }
  },
});

export const getWatchlist = query({
  args: { userId: v.string() },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) return [];

    const saved = await ctx.db
      .query("watchlist")
      .withIndex("by_user", (q) => q.eq("userId", identity.tokenIdentifier))
      .collect();

    const results = await Promise.all(
      saved.map(async (s) => {
        const car = await ctx.db.get(s.carId);
        return car;
      })
    );

    return results.filter(c => c !== null);
  },
});
