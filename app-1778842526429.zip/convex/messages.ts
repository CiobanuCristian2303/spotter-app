import { query, mutation } from "./_generated/server";
import { v } from "convex/values";

export const getConversations = query({
  args: { userId: v.optional(v.string()) },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) return [];
    
    const userId = identity.tokenIdentifier;
    
    const allConversations = await ctx.db.query("conversations").collect();
    const myConversations = allConversations.filter(c => c.participantIds.includes(userId));

    const results = await Promise.all(
      myConversations.map(async (conv) => {
        const car = await ctx.db.get(conv.carId);
        return {
          ...conv,
          car,
        };
      })
    );

    return results.sort((a, b) => b.lastMessageAt - a.lastMessageAt);
  },
});

export const getMessages = query({
  args: { conversationId: v.id("conversations") },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new Error("Unauthenticated");

    const conversation = await ctx.db.get(args.conversationId);
    if (!conversation) throw new Error("Conversation not found");
    
    if (!conversation.participantIds.includes(identity.tokenIdentifier)) {
      throw new Error("Unauthorized");
    }

    return await ctx.db
      .query("messages")
      .withIndex("by_conversationId", (q) => q.eq("conversationId", args.conversationId))
      .collect();
  },
});

export const getOrCreateConversation = mutation({
  args: { carId: v.id("cars"), sellerId: v.string(), buyerId: v.string() },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new Error("Unauthenticated");

    const existing = await ctx.db
      .query("conversations")
      .collect();
    
    const conv = existing.find(c => 
      c.carId === args.carId && 
      c.participantIds.includes(args.buyerId) && 
      c.participantIds.includes(args.sellerId)
    );

    if (conv) return conv._id;

    return await ctx.db.insert("conversations", {
      carId: args.carId,
      participantIds: [args.buyerId, args.sellerId],
      lastMessageAt: Date.now(),
    });
  },
});

export const getDealerLeads = query({
  args: { userId: v.id("users") },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) return [];

    const user = await ctx.db.get(args.userId);
    if (!user || user.tokenIdentifier !== identity.tokenIdentifier) {
      return [];
    }

    const allConversations = await ctx.db.query("conversations").collect();
    const dealerConvs = [];
    for (const conv of allConversations) {
      if (conv.participantIds.includes(user.tokenIdentifier)) {
        const car = await ctx.db.get(conv.carId);
        if (car?.userId === args.userId) {
          dealerConvs.push({ ...conv, car });
        }
      }
    }
    return dealerConvs.sort((a, b) => b.lastMessageAt - a.lastMessageAt);
  },
});

export const sendMessage = mutation({
  args: { 
    conversationId: v.id("conversations"), 
    senderId: v.string(), 
    content: v.string() 
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new Error("Unauthenticated");

    const conversation = await ctx.db.get(args.conversationId);
    if (!conversation || !conversation.participantIds.includes(identity.tokenIdentifier)) {
      throw new Error("Unauthorized");
    }

    await ctx.db.insert("messages", {
      conversationId: args.conversationId,
      senderId: identity.tokenIdentifier,
      content: args.content,
      createdAt: Date.now(),
    });

    await ctx.db.patch(args.conversationId, {
      lastMessageText: args.content,
      lastMessageAt: Date.now(),
    });
  },
});
