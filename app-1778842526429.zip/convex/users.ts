import { query, mutation } from "./_generated/server";
import { v } from "convex/values";

export const me = query({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) return null;
    return await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
  },
});

export const getMe = query({
  args: { tokenIdentifier: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", args.tokenIdentifier))
      .unique();
  },
});

export const upsertUser = mutation({
  args: { tokenIdentifier: v.string(), name: v.optional(v.string()) },
  handler: async (ctx, args) => {
    const existing = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", args.tokenIdentifier))
      .unique();

    if (existing) {
      return existing._id;
    }

    return await ctx.db.insert("users", {
      tokenIdentifier: args.tokenIdentifier,
      name: args.name,
      notificationSettings: {
        messages: true,
        priceDrops: true,
        marketing: false,
      },
    });
  },
});

export const updatePushToken = mutation({
  args: { userId: v.id("users"), pushToken: v.string() },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.userId, { pushToken: args.pushToken });
  },
});

export const updateSettings = mutation({
  args: { 
    userId: v.id("users"), 
    settings: v.object({
      messages: v.boolean(),
      priceDrops: v.boolean(),
      marketing: v.boolean(),
    })
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.userId, { notificationSettings: args.settings });
  },
});

export const getById = query({
  args: { id: v.id("users") },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.id);
  },
});

export const getSellerProfile = query({
  args: { userId: v.id("users") },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.userId);
  },
});
