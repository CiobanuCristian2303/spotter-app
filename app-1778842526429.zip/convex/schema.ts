import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

export default defineSchema({
  users: defineTable({
    tokenIdentifier: v.string(), // For auth identification
    name: v.optional(v.string()),
    email: v.optional(v.string()),
    image: v.optional(v.string()),
    role: v.optional(v.union(v.literal("PRIVATE"), v.literal("DEALER"))),
    companyName: v.optional(v.string()),
    googlePlaceId: v.optional(v.string()),
    rating: v.optional(v.number()),
    reviewCount: v.optional(v.number()),
    pushToken: v.optional(v.string()),
    notificationSettings: v.optional(
      v.object({
        messages: v.boolean(),
        priceDrops: v.boolean(),
        marketing: v.boolean(),
      })
    ),
  }).index("by_token", ["tokenIdentifier"]),

  cars: defineTable({
    userId: v.optional(v.id("users")), // Owner for native listings
    make: v.string(),
    model: v.string(),
    year: v.number(),
    price: v.number(), 
    previousPrice: v.optional(v.number()), 
    currency: v.string(),
    mileage: v.number(),
    vin: v.optional(v.string()),
    location: v.string(),
    lat: v.optional(v.number()),
    lng: v.optional(v.number()),
    sources: v.array(
      v.object({
        platform: v.string(), 
        url: v.optional(v.string()),
        price: v.number(),
        externalId: v.optional(v.string()),
      })
    ),
    images: v.array(v.string()),
    isNative: v.boolean(),
    isSold: v.optional(v.boolean()),
    sellerType: v.union(v.literal("private"), v.literal("dealer")),
    description: v.string(),
    transmission: v.optional(v.string()), // Manual, Automatic
    fuelType: v.optional(v.string()), // Petrol, Diesel, Hybrid, Electric
    engineSize: v.optional(v.number()),
    hp: v.optional(v.number()),
    views: v.optional(v.number()),
    leads: v.optional(v.number()),
    lastRefreshedAt: v.optional(v.number()),
  })
    .index("by_make", ["make"])
    .index("by_price", ["price"])
    .index("by_year", ["year"])
    .index("by_vin", ["vin"])
    .index("by_hp", ["hp"])
    .index("by_mileage", ["mileage"])
    .index("by_isNative", ["isNative"])
    .index("by_userId", ["userId"]),

  messages: defineTable({
    conversationId: v.id("conversations"),
    senderId: v.string(), 
    content: v.string(),
    createdAt: v.number(),
  }).index("by_conversationId", ["conversationId"]),

  conversations: defineTable({
    carId: v.id("cars"),
    participantIds: v.array(v.string()), // [buyerId, sellerId]
    lastMessageText: v.optional(v.string()),
    lastMessageAt: v.number(),
  }).index("by_participant", ["participantIds"]),

  watchlist: defineTable({
    userId: v.string(),
    carId: v.id("cars"),
    savedAt: v.number(),
  })
    .index("by_user", ["userId"])
    .index("by_car", ["carId"])
    .index("by_user_car", ["userId", "carId"]),

  notifications: defineTable({
    userId: v.string(),
    type: v.union(v.literal("message"), v.literal("price_drop"), v.literal("update")),
    title: v.string(),
    body: v.string(),
    data: v.optional(v.any()),
    read: v.boolean(),
    createdAt: v.number(),
  }).index("by_user", ["userId"]),
});
