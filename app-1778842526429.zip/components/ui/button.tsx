import * as React from "react";
import { Pressable, type PressableProps, Platform, View } from "react-native";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "./utils/cn";
import { TextClassContext } from "./utils/text-context";
import { LinearGradient } from 'expo-linear-gradient';

/**
 * Button Component
 * 
 * A versatile button component with multiple variants and sizes.
 * Updated for Trusted Design System v2.0 with metallic gradients.
 */

const buttonVariants = cva(
  "web:ring-offset-background web:transition-colors web:focus-visible:outline-none web:focus-visible:ring-2 web:focus-visible:ring-ring web:focus-visible:ring-offset-2 group flex flex-row items-center justify-center rounded-xl overflow-hidden",
  {
    variants: {
      variant: {
        default:
          "web:hover:opacity-90 bg-primary active:opacity-90",
        destructive:
          "web:hover:opacity-90 bg-destructive active:opacity-90",
        outline:
          "web:hover:bg-accent web:hover:text-accent-foreground border border-platinum/20 bg-transparent",
        secondary:
          "web:hover:opacity-80 bg-secondary active:opacity-80",
        ghost:
          "web:hover:bg-accent web:hover:text-accent-foreground",
        link: "web:underline-offset-4 web:hover:underline web:focus:underline",
        platinum: "bg-platinum web:hover:opacity-90 active:opacity-90",
      },
      size: {
        default: "native:h-14 native:px-6 native:py-3 h-10 px-4 py-2",
        sm: "native:h-10 native:px-4 native:py-2 h-9 rounded-lg px-3",
        lg: "native:h-16 native:px-8 native:py-4 h-12 rounded-xl px-8",
        icon: "native:h-12 native:w-12 h-10 w-10",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
);

const buttonTextVariants = cva("web:transition-colors text-sm font-bold tracking-tight", {
  variants: {
    variant: {
      default: "text-white uppercase text-xs tracking-widest",
      destructive: "text-destructive-foreground",
      outline: "group-active:text-accent-foreground text-platinum",
      secondary: "text-secondary-foreground",
      ghost: "group-active:text-accent-foreground text-platinum",
      link: "text-primary group-active:underline",
      platinum: "text-navy",
    },
    size: {
      default: "",
      sm: "text-[10px]",
      lg: "native:text-base",
      icon: "",
    },
  },
  defaultVariants: {
    variant: "default",
    size: "default",
  },
});

interface ButtonProps
  extends PressableProps,
    VariantProps<typeof buttonVariants> {
  textClass?: string;
}

const Button = React.forwardRef<
  React.ElementRef<typeof Pressable>,
  ButtonProps
>(({ className, textClass, variant, size, children, ...props }, ref) => {
  const androidRipple = Platform.select({
    android: {
      android_ripple: {
        color: variant === "destructive" ? "rgba(239, 68, 68, 0.3)" : "rgba(255, 255, 255, 0.2)",
        borderless: false,
      },
    },
    default: {},
  });

  return (
    <TextClassContext.Provider
      value={cn(
        buttonTextVariants({ variant, size }),
        textClass
      )}
    >
      <Pressable
        className={cn(
          props.disabled && "opacity-50 web:pointer-events-none",
          buttonVariants({ variant, size, className })
        )}
        ref={ref}
        role="button"
        {...androidRipple}
        style={({ pressed }) => [
          Platform.OS === "ios" && pressed && { opacity: 0.8 },
        ]}
        {...props}
      >
        {variant === 'default' && (
          <LinearGradient
            colors={['#007BA7', '#0A111F']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }}
          />
        )}
        <View className="flex-row items-center justify-center gap-2">
          {children}
        </View>
      </Pressable>
    </TextClassContext.Provider>
  );
});
Button.displayName = "Button";

export { Button, buttonVariants, buttonTextVariants };
export type { ButtonProps };
