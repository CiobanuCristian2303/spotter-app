import React from 'react';
import { View, ViewProps } from 'react-native';
import { Text } from './ui/text';
import { Target } from 'lucide-react-native';
import { cn } from './ui/utils/cn';

interface LogoProps extends ViewProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
}

export function Logo({ size = 'md', showText = true, className, ...props }: LogoProps) {
  const iconSize = size === 'sm' ? 24 : size === 'md' ? 32 : size === 'lg' ? 48 : 64;
  const textSize = size === 'sm' ? 'text-xl' : size === 'md' ? 'text-2xl' : size === 'lg' ? 'text-4xl' : 'text-6xl';

  return (
    <View className={cn("flex-row items-center gap-2", className)} {...props}>
      <View className="relative items-center justify-center">
        <Target size={iconSize} className="text-platinum stroke-[1.5]" />
        <View className="absolute inset-0 items-center justify-center">
          <Text className={cn("font-bold text-platinum", size === 'sm' ? 'text-[10px]' : size === 'md' ? 'text-[14px]' : 'text-[20px]')}>
            S
          </Text>
        </View>
      </View>
      {showText && (
        <Text className={cn("font-bold tracking-tight text-platinum", textSize)}>
          Spotter
        </Text>
      )}
    </View>
  );
}
