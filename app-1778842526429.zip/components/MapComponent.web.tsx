import React from 'react';
import { View, Text } from 'react-native';

const MapView = ({ children, className, style, initialRegion }: any) => (
  <View className={className} style={[style, { alignItems: 'center', justifyContent: 'center', backgroundColor: '#111' }]}>
    <Text className="text-muted-foreground font-bold">Interactive Map (Native Only)</Text>
    <Text className="text-[10px] text-muted-foreground mt-2 px-10 text-center">
      Geo-location features are available on iOS and Android. Review listings in List View on web.
    </Text>
    {/* Optional: We could render children here if they are just markers, but they also use native components */}
  </View>
);

const Marker = ({ children }: any) => <View>{children}</View>;
const Callout = ({ children }: any) => <View>{children}</View>;

export default MapView;
export { Marker, Callout };
