const polishedNavy = '#0A111F';
const ceruleanBlue = '#007BA7';
const polishedPlatinum = '#E5E4E2';

export const Colors = {
  light: {
    text: polishedNavy,
    background: polishedPlatinum,
    tint: ceruleanBlue,
    icon: '#687076',
    tabIconDefault: '#687076',
    tabIconSelected: ceruleanBlue,
  },
  dark: {
    text: polishedPlatinum,
    background: polishedNavy,
    tint: ceruleanBlue,
    icon: '#9BA1A6',
    tabIconDefault: '#9BA1A6',
    tabIconSelected: ceruleanBlue,
  },
};
