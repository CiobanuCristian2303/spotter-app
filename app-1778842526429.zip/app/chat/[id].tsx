import React, { useState, useRef, useEffect } from "react";
import { View, FlatList, Image, KeyboardAvoidingView, Platform, ScrollView } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import {
  Text,
  Input,
  Button,
  SafeAreaView,
  Pressable,
} from "@/components/ui";
import {
  ChevronLeft,
  Send,
  MoreVertical,
  ShieldAlert,
} from "lucide-react-native";

const MOCK_USER_ID = "user_123";

export default function ChatScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const [inputText, setInputText] = useState("");
  const flatListRef = useRef<FlatList>(null);

  // Get conversations to find the one we need (since we don't have getConvById yet)
  const conversations = useQuery(api.messages.getConversations, { userId: MOCK_USER_ID });
  const conversation = conversations?.find(c => c._id === id);
  const messages = useQuery(api.messages.getMessages, { conversationId: id as Id<"conversations"> });
  const sendMessage = useMutation(api.messages.sendMessage);

  const handleSend = async () => {
    if (!inputText.trim()) return;
    
    const content = inputText.trim();
    setInputText("");
    
    try {
      await sendMessage({
        conversationId: id as Id<"conversations">,
        senderId: MOCK_USER_ID,
        content,
      });
    } catch (error) {
      console.error("Failed to send message", error);
    }
  };

  useEffect(() => {
    if (messages && messages.length > 0) {
      setTimeout(() => {
        flatListRef.current?.scrollToEnd({ animated: true });
      }, 100);
    }
  }, [messages]);

  if (!conversation) return null;

  const renderMessage = ({ item }: { item: any }) => {
    const isMe = item.senderId === MOCK_USER_ID;
    
    return (
      <View className={`mb-3 flex-row ${isMe ? "justify-end" : "justify-start"}`}>
        <View 
          className={`max-w-[80%] rounded-2xl px-4 py-3 ${
            isMe ? "bg-primary rounded-tr-none" : "bg-secondary rounded-tl-none"
          }`}
        >
          <Text className={`${isMe ? "text-primary-foreground" : "text-foreground"}`}>
            {item.content}
          </Text>
          <Text 
            className={`mt-1 text-[8px] opacity-70 ${
              isMe ? "text-primary-foreground text-right" : "text-muted-foreground"
            }`}
          >
            {new Date(item.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </Text>
        </View>
      </View>
    );
  };

  return (
    <View className="flex-1 bg-background">
      {/* Custom Header */}
      <SafeAreaView edges={["top"]} className="bg-card border-b border-border">
        <View className="flex-row items-center px-4 py-2">
          <Button variant="ghost" size="icon" onPress={() => router.back()} className="-ml-2">
            <ChevronLeft size={24} className="text-foreground" />
          </Button>
          
          <View className="flex-1 flex-row items-center ml-2">
            <Image 
              source={{ uri: conversation.car?.images[0] }} 
              className="h-10 w-10 rounded-lg bg-secondary"
            />
            <View className="ml-3">
              <Text className="font-bold text-foreground leading-tight" numberOfLines={1}>
                {conversation.car?.make} {conversation.car?.model}
              </Text>
              <Text className="text-xs text-primary font-bold">
                {conversation.car?.price.toLocaleString()} {conversation.car?.currency}
              </Text>
            </View>
          </View>
          
          <Button variant="ghost" size="icon">
            <MoreVertical size={20} className="text-muted-foreground" />
          </Button>
        </View>
      </SafeAreaView>

      {/* Safety Banner */}
      <View className="bg-secondary/30 px-4 py-2 flex-row items-center gap-2">
        <ShieldAlert size={14} className="text-muted-foreground" />
        <Text className="text-[10px] text-muted-foreground flex-1">
          Stay safe. Never send money before seeing the car in person.
        </Text>
      </View>

      <KeyboardAvoidingView 
        behavior={Platform.OS === "ios" ? "padding" : "height"} 
        className="flex-1"
        keyboardVerticalOffset={0}
      >
        <FlatList
          ref={flatListRef}
          data={messages}
          renderItem={renderMessage}
          keyExtractor={(item) => item._id}
          contentContainerStyle={{ padding: 16, paddingBottom: 20 }}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
             <View className="py-10 items-center">
               <Text className="text-muted-foreground italic text-sm">Say hello to the seller!</Text>
             </View>
          }
        />

        <View className="border-t border-border bg-card p-4 pb-10">
          <View className="flex-row items-center gap-2">
            <View className="flex-1">
              <Input
                placeholder="Type a message..."
                value={inputText}
                onChangeText={setInputText}
                className="bg-secondary/50 border-0 h-12"
              />
            </View>
            <Button 
              size="icon" 
              className="h-12 w-12 rounded-full" 
              onPress={handleSend}
              disabled={!inputText.trim()}
            >
              <Send size={20} className="text-primary-foreground" />
            </Button>
          </View>
        </View>
      </KeyboardAvoidingView>
    </View>
  );
}
