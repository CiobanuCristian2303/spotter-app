import React, { useState, useEffect } from "react";
import { View, ScrollView, FlatList, Modal, StyleSheet, Dimensions } from "react-native";
import { Image } from "expo-image";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api";
import {
  Text,
  Input,
  Card,
  CardContent,
  Badge,
  Button,
  SafeAreaView,
  Pressable,
  Label,
} from "@/components/ui";
import { 
  Search, 
  SlidersHorizontal, 
  MapPin, 
  Gauge, 
  Calendar, 
  X, 
  Heart, 
  TrendingDown, 
  Zap,
  Map as MapIcon,
  List as ListIcon,
  ChevronDown,
  Star,
} from "lucide-react-native";
import { useRouter } from "expo-router";
import MapView, { Marker, Callout } from "@/components/MapComponent";
import { Logo } from "@/components/Logo";

// Cast to any to avoid JSX typing issues in this environment
const MapViewAny = MapView as any;
const MarkerAny = Marker as any;
const CalloutAny = Callout as any;

// Mock user ID for now
const USER_ID = "mock_user_123";

export default function HomeScreen() {
  const [searchQuery, setSearchQuery] = useState("");
  const [viewMode, setViewMode] = useState<"list" | "map">("list");
  const [isFilterVisible, setIsFilterVisible] = useState(false);
  const [isMakePickerVisible, setIsMakePickerVisible] = useState(false);
  
  const [filters, setFilters] = useState({
    make: "All",
    model: "",
    minPrice: undefined as number | undefined,
    maxPrice: undefined as number | undefined,
    minYear: undefined as number | undefined,
    maxYear: undefined as number | undefined,
    minMileage: undefined as number | undefined,
    maxMileage: undefined as number | undefined,
    minHP: undefined as number | undefined,
    maxHP: undefined as number | undefined,
    fuelType: "Any",
    transmission: "Any",
  });

  const cars = useQuery(api.cars.list, {
    make: filters.make === "All" ? undefined : filters.make,
    model: searchQuery || filters.model || undefined,
    minPrice: filters.minPrice,
    maxPrice: filters.maxPrice,
    minYear: filters.minYear,
    maxYear: filters.maxYear,
    minMileage: filters.minMileage,
    maxMileage: filters.maxMileage,
    minHP: filters.minHP,
    maxHP: filters.maxHP,
    fuelType: filters.fuelType === "Any" ? undefined : filters.fuelType,
    transmission: filters.transmission === "Any" ? undefined : filters.transmission,
  });

  const watchlist = useQuery(api.cars.getWatchlist, { userId: USER_ID });
  const toggleWatchlist = useMutation(api.cars.toggleWatchlist);
  const incrementViews = useMutation(api.cars.incrementViews);

  const router = useRouter();

  const makes = ["All", "BMW", "Audi", "Volkswagen", "Mercedes-Benz", "Dacia", "Toyota", "Tesla", "Porsche", "Ford", "Hyundai"];
  const fuels = ["Any", "Petrol", "Diesel", "Hybrid", "Electric"];
  const gears = ["Any", "Manual", "Automatic"];

  const handleCarPress = (item: any) => {
    incrementViews({ id: item._id });
    router.push(`/car/${item._id}`);
  };

  const renderCarCard = ({ item }: { item: any }) => {
    const isWatched = watchlist?.some(w => w._id === item._id);
    const priceDrop = item.previousPrice && item.previousPrice > item.price 
      ? item.previousPrice - item.price 
      : null;

    return (
      <Card className="mb-6 border-platinum/10 bg-navy/40">
        <Pressable onPress={() => handleCarPress(item)}>
          <View className="relative">
            <Image
              source={{ uri: item.images[0] }}
              className="h-56 w-full"
              resizeMode="cover"
            />
            <View className="absolute right-3 top-3 flex-row gap-2">
              <Pressable 
                onPress={(e) => {
                  e.stopPropagation();
                  toggleWatchlist({ userId: USER_ID, carId: item._id });
                }}
                className="h-10 w-10 items-center justify-center rounded-full bg-navy/60 backdrop-blur-md border border-platinum/10"
              >
                <Heart 
                  size={20} 
                  className={isWatched ? "fill-cerulean text-cerulean" : "text-platinum"} 
                />
              </Pressable>
            </View>
            
            <View className="absolute left-3 top-3 flex-row gap-2">
              {item.isNative && (
                <Badge variant="gold">
                  <Text>Verified</Text>
                </Badge>
              )}
              {priceDrop && (
                <Badge variant="outline" className="bg-emerald-500/20 border-emerald-500/40">
                  <TrendingDown size={10} className="mr-1 text-emerald-400" />
                  <Text className="text-emerald-400">-{priceDrop.toLocaleString()} €</Text>
                </Badge>
              )}
            </View>

            <View className="absolute bottom-3 left-3 flex-row gap-1">
              {item.sources.map((s: any, idx: number) => (
                <Badge 
                  key={idx}
                  variant="outline"
                  className="bg-navy/60 border-platinum/20"
                >
                  <Text className="text-[8px] font-bold uppercase text-platinum/70">{s.platform}</Text>
                </Badge>
              ))}
            </View>
          </View>
          <CardContent className="p-5">
            <View className="mb-3 flex-row items-center justify-between">
              <Text className="text-xl font-bold text-platinum tracking-tight">
                {item.make} {item.model}
              </Text>
              <View className="items-end">
                <Text className="text-xl font-bold text-cerulean">
                  {item.price.toLocaleString()} {item.currency}
                </Text>
                {item.previousPrice && (
                  <Text className="text-[10px] text-muted-foreground line-through">
                     {item.previousPrice.toLocaleString()} {item.currency}
                  </Text>
                )}
              </View>
            </View>

            <View className="mb-5 flex-row flex-wrap gap-x-5 gap-y-2">
              <View className="flex-row items-center gap-1.5">
                <Calendar size={14} className="text-muted-foreground stroke-[1.5]" />
                <Text className="text-sm font-medium text-muted-foreground">{item.year}</Text>
              </View>
              <View className="flex-row items-center gap-1.5">
                <Gauge size={14} className="text-muted-foreground stroke-[1.5]" />
                <Text className="text-sm font-medium text-muted-foreground">
                  {item.mileage.toLocaleString()} km
                </Text>
              </View>
              <View className="flex-row items-center gap-1.5">
                <Zap size={14} className="text-muted-foreground stroke-[1.5]" />
                <Text className="text-sm font-medium text-muted-foreground">{item.hp || "N/A"} CP</Text>
              </View>
              <View className="flex-row items-center gap-1.5">
                <MapPin size={14} className="text-muted-foreground stroke-[1.5]" />
                <Text className="text-sm font-medium text-muted-foreground">{item.location}</Text>
              </View>
            </View>

            <View className="flex-row items-center justify-between border-t border-platinum/5 pt-5">
              <View className="flex-row items-center gap-2">
                <Badge variant="platinum">
                  <Text>{item.sellerType}</Text>
                </Badge>
                {item.sources.length > 1 && (
                  <Badge variant="outline" className="bg-emerald-500/10 border-emerald-500/20">
                    <Text className="text-emerald-400">Best Price</Text>
                  </Badge>
                )}
              </View>
              <Button size="sm" variant="outline" className="h-9 px-5">
                <Text>Details</Text>
              </Button>
            </View>
          </CardContent>
        </Pressable>
      </Card>
    );
  };

  const initialRegion = {
    latitude: 44.4268,
    longitude: 26.1025,
    latitudeDelta: 0.5,
    longitudeDelta: 0.5,
  };

  return (
    <SafeAreaView className="flex-1 bg-navy" edges={["top"]}>
      <View className="px-5 py-4">
        <View className="mb-5 flex-row items-center justify-between">
          <Logo size="md" />
          <View className="flex-row gap-2">
            <Button 
              variant="outline" 
              size="icon" 
              className="rounded-full bg-navy/40 border-platinum/10 w-11 h-11"
              onPress={() => setViewMode(viewMode === "list" ? "map" : "list")}
            >
              {viewMode === "list" ? <MapIcon size={20} className="text-platinum stroke-[1.5]" /> : <ListIcon size={20} className="text-platinum stroke-[1.5]" />}
            </Button>
            <Button 
              variant="ghost" 
              size="icon" 
              className="rounded-full bg-navy/40 w-11 h-11"
              onPress={() => setIsFilterVisible(true)}
            >
              <SlidersHorizontal size={20} className="text-platinum stroke-[1.5]" />
            </Button>
          </View>
        </View>

        {/* Quick Filter Bar */}
        <View className="flex-row gap-3 mb-5">
           <Pressable 
            onPress={() => setIsMakePickerVisible(true)}
            className="flex-1 flex-row items-center justify-between px-4 py-3 rounded-xl bg-navy/40 border border-platinum/10"
           >
              <Text className="text-sm font-bold text-platinum">{filters.make === "All" ? "Make" : filters.make}</Text>
              <ChevronDown size={16} className="text-platinum/50" />
           </Pressable>
           <View className="flex-[1.5] relative">
              <View className="absolute left-3 top-3 z-10">
                <Search size={18} className="text-platinum/40" />
              </View>
              <Input
                placeholder="Search Model..."
                value={searchQuery}
                onChangeText={setSearchQuery}
                className="pl-10 h-12 border-platinum/10 bg-navy/40 rounded-xl text-platinum font-medium"
                placeholderTextColor="rgba(229, 228, 226, 0.4)"
              />
           </View>
        </View>

        {viewMode === "list" && (
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            className="mb-2 -mx-5 px-5"
          >
            <View className="flex-row gap-2">
              <Pressable onPress={() => setFilters(prev => ({ ...prev, maxMileage: 100000 }))}>
                  <Badge variant={filters.maxMileage === 100000 ? "platinum" : "outline"} className="px-5 py-2.5">
                    <Text>Under 100k KM</Text>
                  </Badge>
              </Pressable>
              <Pressable onPress={() => setFilters(prev => ({ ...prev, minHP: 200 }))}>
                  <Badge variant={filters.minHP === 200 ? "platinum" : "outline"} className="px-5 py-2.5">
                    <Text>Power 200+ CP</Text>
                  </Badge>
              </Pressable>
              {makes.slice(1, 6).map((make) => (
                <Pressable 
                  key={make} 
                  onPress={() => setFilters(prev => ({ ...prev, make }))}
                >
                  <Badge
                    variant={make === filters.make ? "platinum" : "outline"}
                    className="px-5 py-2.5"
                  >
                    <Text>
                      {make}
                    </Text>
                  </Badge>
                </Pressable>
              ))}
            </View>
          </ScrollView>
        )}
      </View>

      {viewMode === "list" ? (
        <FlatList
          data={cars}
          renderItem={renderCarCard}
          keyExtractor={(item) => item._id}
          contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 100 }}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <View className="py-20 items-center">
              <Text className="text-muted-foreground font-medium">No listings found matching criteria</Text>
            </View>
          }
        />
      ) : (
        <View className="flex-1 overflow-hidden rounded-t-[40px] border-t border-platinum/10 bg-navy shadow-2xl">
           <MapViewAny
            className="flex-1"
            initialRegion={initialRegion}
            userInterfaceStyle="dark"
           >
             {cars?.map((car: any) => car.lat && car.lng && (
               <MarkerAny
                key={car._id}
                coordinate={{ latitude: car.lat, longitude: car.lng }}
                title={`${car.make} ${car.model}`}
                description={`${car.price.toLocaleString()} €`}
               >
                  <View className="bg-cerulean px-3 py-2 rounded-xl border border-platinum/20 shadow-lg">
                    <Text className="text-white text-[10px] font-bold">{car.price.toLocaleString()} €</Text>
                  </View>
                  <CalloutAny tooltip onPress={() => handleCarPress(car)}>
                    <View className="bg-navy p-3 rounded-2xl border border-platinum/10 w-56 shadow-2xl">
                      <Image source={{ uri: car.images[0] }} className="h-28 w-full rounded-xl mb-3" />
                      <Text className="font-bold text-platinum text-sm mb-1">{car.make} {car.model}</Text>
                      <View className="flex-row items-center justify-between">
                        <Text className="text-cerulean font-bold text-sm">{car.price.toLocaleString()} €</Text>
                        <Text className="text-[10px] text-muted-foreground font-medium">{car.year}</Text>
                      </View>
                    </View>
                  </CalloutAny>
               </MarkerAny>
             ))}
           </MapViewAny>
           <View className="absolute bottom-12 left-5 right-5">
              <Card className="bg-navy/80 border-platinum/10 shadow-2xl backdrop-blur-xl">
                <CardContent className="p-5 flex-row items-center gap-4">
                   <View className="h-12 w-12 rounded-2xl bg-cerulean/20 items-center justify-center border border-cerulean/20">
                      <MapPin size={24} className="text-cerulean stroke-[1.5]" />
                   </View>
                   <View className="flex-1">
                      <Text className="font-bold text-platinum">Interactive Map</Text>
                      <Text className="text-xs text-muted-foreground font-medium">{cars?.length || 0} listings in region</Text>
                   </View>
                   <Button size="sm" variant="outline" className="h-9" onPress={() => setViewMode("list")}>
                      <Text>List</Text>
                   </Button>
                </CardContent>
              </Card>
           </View>
        </View>
      )}

      {/* Make Picker Modal */}
      <Modal
        visible={isMakePickerVisible}
        animationType="fade"
        transparent={true}
        onRequestClose={() => setIsMakePickerVisible(false)}
      >
        <Pressable 
          className="flex-1 bg-navy/80 items-center justify-center p-6 backdrop-blur-sm"
          onPress={() => setIsMakePickerVisible(false)}
        >
          <View className="w-full bg-navy rounded-[32px] border border-platinum/10 overflow-hidden shadow-2xl">
            <View className="p-6 border-b border-platinum/5 flex-row justify-between items-center bg-platinum/5">
              <Text className="text-xl font-bold text-platinum">Select Manufacturer</Text>
              <Pressable onPress={() => setIsMakePickerVisible(false)} className="h-8 w-8 items-center justify-center rounded-full bg-platinum/10">
                <X size={18} className="text-platinum" />
              </Pressable>
            </View>
            <ScrollView className="max-h-[450px]">
              <View className="p-4 gap-2">
                {makes.map((make) => (
                  <Pressable 
                    key={make}
                    onPress={() => {
                      setFilters(prev => ({ ...prev, make }));
                      setIsMakePickerVisible(false);
                    }}
                    className={`px-5 py-4 rounded-2xl flex-row items-center justify-between ${filters.make === make ? "bg-cerulean/10 border border-cerulean/20" : "bg-transparent"}`}
                  >
                    <Text className={`font-bold ${filters.make === make ? "text-cerulean" : "text-platinum"}`}>{make}</Text>
                    {filters.make === make && <View className="bg-cerulean h-2 w-2 rounded-full" />}
                  </Pressable>
                ))}
              </View>
            </ScrollView>
          </View>
        </Pressable>
      </Modal>

      <Modal
        visible={isFilterVisible}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setIsFilterVisible(false)}
      >
        <SafeAreaView className="flex-1 bg-navy">
          <View className="flex-1 px-6 py-6">
            <View className="mb-8 flex-row items-center justify-between">
              <Text className="text-2xl font-bold text-platinum tracking-tight">Advanced Filters</Text>
              <Pressable onPress={() => setIsFilterVisible(false)} className="h-10 w-10 items-center justify-center rounded-full bg-platinum/10">
                <X size={24} className="text-platinum" />
              </Pressable>
            </View>

            <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
              <Text className="mb-4 font-bold text-lg text-platinum">Price Range (EUR)</Text>
              <View className="mb-8 flex-row gap-4">
                <View className="flex-1">
                  <Label className="mb-2 text-platinum/60">Min Price</Label>
                  <Input
                    keyboardType="numeric"
                    placeholder="0"
                    value={filters.minPrice?.toString()}
                    onChangeText={(v) => setFilters(prev => ({ ...prev, minPrice: v ? parseInt(v) : undefined }))}
                    className="bg-platinum/5 border-platinum/10 text-platinum h-12 rounded-xl"
                  />
                </View>
                <View className="flex-1">
                  <Label className="mb-2 text-platinum/60">Max Price</Label>
                  <Input
                    keyboardType="numeric"
                    placeholder="Any"
                    value={filters.maxPrice?.toString()}
                    onChangeText={(v) => setFilters(prev => ({ ...prev, maxPrice: v ? parseInt(v) : undefined }))}
                    className="bg-platinum/5 border-platinum/10 text-platinum h-12 rounded-xl"
                  />
                </View>
              </View>

              <Text className="mb-4 font-bold text-lg text-platinum">Performance (CP)</Text>
              <View className="mb-8 flex-row gap-4">
                <View className="flex-1">
                  <Label className="mb-2 text-platinum/60">Min HP</Label>
                  <Input
                    keyboardType="numeric"
                    placeholder="0"
                    value={filters.minHP?.toString()}
                    onChangeText={(v) => setFilters(prev => ({ ...prev, minHP: v ? parseInt(v) : undefined }))}
                    className="bg-platinum/5 border-platinum/10 text-platinum h-12 rounded-xl"
                  />
                </View>
                <View className="flex-1">
                  <Label className="mb-2 text-platinum/60">Max HP</Label>
                  <Input
                    keyboardType="numeric"
                    placeholder="Any"
                    value={filters.maxHP?.toString()}
                    onChangeText={(v) => setFilters(prev => ({ ...prev, maxHP: v ? parseInt(v) : undefined }))}
                    className="bg-platinum/5 border-platinum/10 text-platinum h-12 rounded-xl"
                  />
                </View>
              </View>

              <Text className="mb-4 font-bold text-lg text-platinum">Fuel Type</Text>
              <View className="mb-8 flex-row flex-wrap gap-2">
                {fuels.map(f => (
                  <Pressable key={f} onPress={() => setFilters(p => ({ ...p, fuelType: f }))}>
                    <Badge variant={filters.fuelType === f ? "platinum" : "outline"} className="px-5 py-3">
                      <Text>{f}</Text>
                    </Badge>
                  </Pressable>
                ))}
              </View>

              <Text className="mb-4 font-bold text-lg text-platinum">Transmission</Text>
              <View className="mb-8 flex-row gap-2">
                {gears.map(g => (
                  <Pressable key={g} onPress={() => setFilters(p => ({ ...p, transmission: g }))}>
                    <Badge variant={filters.transmission === g ? "platinum" : "outline"} className="px-5 py-3">
                      <Text>{g}</Text>
                    </Badge>
                  </Pressable>
                ))}
              </View>

              <Text className="mb-4 font-bold text-lg text-platinum">Mileage Range (KM)</Text>
              <View className="mb-8 flex-row gap-4">
                <View className="flex-1">
                  <Label className="mb-2 text-platinum/60">Min KM</Label>
                  <Input
                    keyboardType="numeric"
                    placeholder="0"
                    value={filters.minMileage?.toString()}
                    onChangeText={(v) => setFilters(prev => ({ ...prev, minMileage: v ? parseInt(v) : undefined }))}
                    className="bg-platinum/5 border-platinum/10 text-platinum h-12 rounded-xl"
                  />
                </View>
                <View className="flex-1">
                  <Label className="mb-2 text-platinum/60">Max KM</Label>
                  <Input
                    keyboardType="numeric"
                    placeholder="Any"
                    value={filters.maxMileage?.toString()}
                    onChangeText={(v) => setFilters(prev => ({ ...prev, maxMileage: v ? parseInt(v) : undefined }))}
                    className="bg-platinum/5 border-platinum/10 text-platinum h-12 rounded-xl"
                  />
                </View>
              </View>
            </ScrollView>

            <View className="mt-4 flex-row gap-4">
              <Button 
                variant="outline" 
                className="flex-1 h-14"
                onPress={() => {
                  setFilters({
                    make: "All",
                    model: "",
                    minPrice: undefined,
                    maxPrice: undefined,
                    minYear: undefined,
                    maxYear: undefined,
                    minMileage: undefined,
                    maxMileage: undefined,
                    minHP: undefined,
                    maxHP: undefined,
                    fuelType: "Any",
                    transmission: "Any",
                  });
                }}
              >
                <Text>Reset</Text>
              </Button>
              <Button 
                className="flex-1 h-14"
                onPress={() => setIsFilterVisible(false)}
              >
                <Text>Show Results</Text>
              </Button>
            </View>
          </View>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}
