import React, { useState } from "react";
import { View, ScrollView, Image, ActivityIndicator, Alert, Switch, Pressable } from "react-native";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api";
import {
  Text,
  Button,
  SafeAreaView,
  Card,
  CardContent,
  Badge,
  Input,
  Label,
} from "@/components/ui";
import {
  User,
  Settings,
  LogOut,
  MapPin,
  Calendar,
  ChevronRight,
  Briefcase,
  ShieldCheck,
  Star,
  Bell,
  TrendingUp,
  Zap,
  Eye,
  MessageSquare,
  RefreshCw,
  CheckCircle,
} from "lucide-react-native";
import { useRouter } from "expo-router";
import { Logo } from "@/components/Logo";

export default function ProfileScreen() {
  const me = useQuery(api.users.me);
  const router = useRouter();

  if (me === undefined) {
    return (
      <SafeAreaView className="flex-1 bg-navy items-center justify-center">
        <ActivityIndicator color="#007BA7" />
      </SafeAreaView>
    );
  }

  const user = me || {
    _id: "mock_id" as any,
    name: "Spotter Pro User",
    email: "dealer@spotter.ro",
    role: "DEALER" as const,
    companyName: "Spotter Elite Motors",
    notificationSettings: { messages: true, priceDrops: true, marketing: false },
    googlePlaceId: "",
    rating: 4.8,
    reviewCount: 124
  };

  const toggleSetting = (key: 'messages' | 'priceDrops' | 'marketing') => {
    // In a real app we'd call updateSettings mutation
  };

  return (
    <SafeAreaView className="flex-1 bg-navy" edges={["top"]}>
      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        <View className="items-center px-6 py-10">
          <View className="relative mb-6">
            <View className="h-28 w-28 items-center justify-center rounded-[32px] bg-platinum/5 border border-platinum/10 shadow-2xl">
              <User size={56} className="text-platinum/20 stroke-[1.5]" />
            </View>
            {user.role === "DEALER" && (
               <View className="absolute -bottom-2 -right-2 rounded-2xl bg-cerulean p-2 border-4 border-navy shadow-xl">
                  <ShieldCheck size={20} className="text-white" />
               </View>
            )}
          </View>
          
          <Text className="text-3xl font-bold text-platinum tracking-tight text-center">
             {user.role === "DEALER" ? user.companyName : (user.name || "Spotter User")}
          </Text>
          <Text className="text-sm text-muted-foreground font-medium mt-1 uppercase tracking-widest">{user.email || "No email set"}</Text>
          
          <View className="mt-6 flex-row gap-3">
            <Badge variant="gold" className="px-4 py-1.5 h-8">
              <Text>{user.role || "PRIVATE"}</Text>
            </Badge>
            <Button variant="outline" size="sm" className="h-8 px-4 border-platinum/10 bg-navy/40">
               <Settings size={14} className="text-platinum" />
               <Text className="text-[10px] ml-2 text-platinum uppercase tracking-widest">Settings</Text>
            </Button>
          </View>
        </View>

        {user.role === "DEALER" ? (
          <DealerPortal userId={user._id} />
        ) : (
          <UserSettings user={user} toggleSetting={toggleSetting} />
        )}

        <View className="px-6 mt-10">
          <Button 
            variant="outline" 
            className="flex-row gap-2 border-destructive/20 bg-destructive/5 h-14"
            onPress={() => Alert.alert("Sign Out", "Are you sure?")}
          >
            <LogOut size={20} className="text-destructive" />
            <Text className="font-bold text-destructive uppercase tracking-widest text-xs">Terminate Session</Text>
          </Button>
        </View>

        <View className="mt-12 mb-16 items-center">
          <Logo size="sm" className="opacity-30" />
          <Text className="text-[10px] text-muted-foreground uppercase tracking-[4px] font-bold mt-4">Trusted System v2.0</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

function DealerPortal({ userId }: { userId: any }) {
  const inventory = useQuery(api.cars.getDealerInventory, { userId });
  const leads = useQuery(api.messages.getDealerLeads, { userId });
  const me = useQuery(api.users.me);
  const refreshListing = useMutation(api.cars.refreshListing);
  const markAsSold = useMutation(api.cars.markAsSold);
  const router = useRouter();

  const [placeId, setPlaceId] = useState(me?.googlePlaceId || "");

  const totalViews = inventory?.reduce((acc: number, curr: any) => acc + (curr.views || 0), 0) || 0;
  const totalLeads = inventory?.reduce((acc: number, curr: any) => acc + (curr.leads || 0), 0) || 0;
  const conversionRate = totalViews > 0 ? ((totalLeads / totalViews) * 100).toFixed(1) : "0";

  return (
    <View className="px-6 gap-8">
      <View>
        <Text className="text-2xl font-bold text-platinum tracking-tight mb-6 px-1">Professional Analytics</Text>
        <View className="flex-row gap-4">
          <Card className="flex-1 border-platinum/10 bg-navy/40 shadow-xl">
              <CardContent className="p-5 items-center">
                <View className="h-10 w-10 rounded-xl bg-cerulean/10 items-center justify-center mb-3">
                    <Eye size={20} className="text-cerulean" />
                </View>
                <Text className="text-2xl font-bold text-platinum">{totalViews}</Text>
                <Text className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest mt-1">Views</Text>
              </CardContent>
          </Card>
          <Card className="flex-1 border-platinum/10 bg-navy/40 shadow-xl">
              <CardContent className="p-5 items-center">
                <View className="h-10 w-10 rounded-xl bg-emerald-500/10 items-center justify-center mb-3">
                    <MessageSquare size={20} className="text-emerald-500" />
                </View>
                <Text className="text-2xl font-bold text-platinum">{totalLeads}</Text>
                <Text className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest mt-1">Leads</Text>
              </CardContent>
          </Card>
          <Card className="flex-1 border-platinum/10 bg-navy/40 shadow-xl">
              <CardContent className="p-5 items-center">
                <View className="h-10 w-10 rounded-xl bg-gold/10 items-center justify-center mb-3">
                    <TrendingUp size={20} className="text-gold" />
                </View>
                <Text className="text-2xl font-bold text-platinum">{conversionRate}%</Text>
                <Text className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest mt-1">Conv.</Text>
              </CardContent>
          </Card>
        </View>
      </View>
      
      <View>
        <Text className="text-xl font-bold text-platinum tracking-tight mb-4 px-1">Reputation Sync</Text>
        <Card className="border-platinum/10 bg-navy/40 shadow-xl">
          <CardContent className="p-6">
              <View className="flex-row items-center gap-4 mb-5">
                <View className="h-12 w-12 rounded-2xl bg-cerulean/10 items-center justify-center border border-cerulean/20">
                    <Star size={24} className="text-cerulean stroke-[1.5]" />
                </View>
                <View className="flex-1">
                    <Text className="font-bold text-platinum text-lg">Google Reviews</Text>
                    <Text className="text-xs text-muted-foreground font-medium">Verify your dealership reputation</Text>
                </View>
              </View>
              <View className="flex-row gap-3">
                <Input 
                    placeholder="Place ID..." 
                    className="flex-1 h-12 bg-platinum/5 border-platinum/10 text-platinum rounded-xl"
                    value={placeId}
                    onChangeText={setPlaceId}
                />
                <Button variant="platinum" className="h-12 px-6">
                    <Text>SYNC</Text>
                </Button>
              </View>
          </CardContent>
        </Card>
      </View>

      {leads && leads.length > 0 && (
        <View>
           <Text className="text-xl font-bold text-platinum tracking-tight mb-4 px-1">Active Inquiries</Text>
           <ScrollView horizontal showsHorizontalScrollIndicator={false} className="-mx-6 px-6">
              <View className="flex-row gap-4">
                 {leads.map((lead: any) => (
                    <Pressable key={lead._id} onPress={() => router.push(`/chat/${lead._id}`)}>
                       <Card className="w-72 border-cerulean/20 bg-cerulean/5 shadow-2xl">
                          <CardContent className="p-4 flex-row gap-4 items-center">
                             <Image source={{ uri: lead.car?.images[0] }} className="h-16 w-16 rounded-2xl border border-platinum/10" />
                             <View className="flex-1">
                                <Text className="font-bold text-platinum" numberOfLines={1}>{lead.car?.make} {lead.car?.model}</Text>
                                <Text className="text-xs text-muted-foreground font-medium mt-1" numberOfLines={1}>{lead.lastMessageText || "Pending verification..."}</Text>
                             </View>
                             <View className="h-2.5 w-2.5 rounded-full bg-cerulean shadow-[0_0_10px_rgba(0,123,167,0.8)]" />
                          </CardContent>
                       </Card>
                    </Pressable>
                 ))}
              </View>
           </ScrollView>
        </View>
      )}

      <View>
        <Text className="text-xl font-bold text-platinum tracking-tight mb-4 px-1">Inventory Control ({inventory?.length || 0})</Text>
        <View className="gap-5">
          {inventory?.map((car: any) => (
            <Card key={car._id} className={`border-platinum/10 bg-navy/40 shadow-xl overflow-hidden ${car.isSold ? 'opacity-40' : ''}`}>
               <View className="flex-row">
                  <Image source={{ uri: car.images[0] }} className="h-32 w-32" />
                  <View className="flex-1 p-4 justify-between">
                     <View className="flex-row justify-between items-start">
                        <View>
                          <Text className="font-bold text-platinum text-lg">{car.make} {car.model}</Text>
                          <Text className="text-xs text-muted-foreground font-bold mt-1 uppercase tracking-widest">{car.year} • {car.price.toLocaleString()} €</Text>
                        </View>
                        {car.isSold && <Badge variant="destructive" className="h-5 px-1.5 border-0"><Text className="text-[8px] text-white">ARCHIVED</Text></Badge>}
                     </View>
                     
                     <View className="flex-row gap-3 mt-3">
                        {!car.isSold && (
                          <>
                            <Button variant="outline" className="flex-1 h-10 border-platinum/10 bg-navy/60" onPress={() => refreshListing({ id: car._id })}>
                              <RefreshCw size={14} className="text-platinum" />
                              <Text className="text-[10px] ml-2 text-platinum uppercase font-bold tracking-widest">Bump</Text>
                            </Button>
                            <Button variant="outline" className="flex-1 h-10 border-emerald-500/20 bg-emerald-500/5" onPress={() => markAsSold({ id: car._id })}>
                              <CheckCircle size={14} className="text-emerald-500" />
                              <Text className="text-[10px] ml-2 text-emerald-500 uppercase font-bold tracking-widest">Sold</Text>
                            </Button>
                          </>
                        )}
                     </View>
                  </View>
               </View>
            </Card>
          ))}
        </View>
      </View>
    </View>
  );
}

function UserSettings({ user, toggleSetting }: { user: any, toggleSetting: any }) {
  return (
    <View className="px-6 gap-6">
      <Text className="text-xl font-bold text-platinum tracking-tight px-1">Alert Configurations</Text>
      <Card className="border-platinum/10 bg-navy/40 shadow-2xl">
        <CardContent className="p-6 gap-8">
          <View className="flex-row items-center justify-between">
            <View className="flex-row items-center gap-4">
              <View className="h-12 w-12 items-center justify-center rounded-2xl bg-cerulean/10 border border-cerulean/20">
                <Bell size={24} className="text-cerulean stroke-[1.5]" />
              </View>
              <View>
                <Text className="font-bold text-platinum text-lg">Direct Inquiries</Text>
                <Text className="text-xs text-muted-foreground font-medium">Push alerts for lead generation</Text>
              </View>
            </View>
            <Switch 
              value={user.notificationSettings?.messages || false} 
              onValueChange={() => toggleSetting('messages')}
              trackColor={{ true: '#007BA7', false: '#1A212E' }} 
            />
          </View>
          
          <View className="h-[1px] bg-platinum/5" />
          
          <View className="flex-row items-center justify-between">
            <View className="flex-row items-center gap-4">
              <View className="h-12 w-12 items-center justify-center rounded-2xl bg-gold/10 border border-gold/20">
                <Star size={24} className="text-gold stroke-[1.5]" />
              </View>
              <View>
                <Text className="font-bold text-platinum text-lg">Market Volatility</Text>
                <Text className="text-xs text-muted-foreground font-medium">Alerts for watchlist price drops</Text>
              </View>
            </View>
            <Switch 
              value={user.notificationSettings?.priceDrops || false} 
              onValueChange={() => toggleSetting('priceDrops')}
              trackColor={{ true: '#007BA7', false: '#1A212E' }} 
            />
          </View>
        </CardContent>
      </Card>
      
      <Button className="mt-6 flex-row gap-3 bg-cerulean h-16 shadow-lg shadow-cerulean/30">
         <Briefcase size={24} className="text-white stroke-[1.5]" />
         <View>
            <Text className="font-bold text-white uppercase text-xs tracking-widest">Upgrade to Spotter Pro</Text>
            <Text className="text-[10px] text-white/70">Access professional dealer tools & CRM</Text>
         </View>
      </Button>
    </View>
  );
}
