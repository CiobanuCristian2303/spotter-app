import React from "react";
import { View, FlatList, Pressable } from "react-native";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Text, SafeAreaView, Card, CardContent, Badge, Button } from "@/components/ui";
import { Bell, MessageSquare, TrendingDown, Info, Circle, CheckCircle2 } from "lucide-react-native";
import { useRouter } from "expo-router";

const USER_ID = "mock_user_123";

export default function NotificationsScreen() {
  const notifications = useQuery(api.notifications.list, { userId: USER_ID });
  const markAsRead = useMutation(api.notifications.markAsRead);
  const markAllAsRead = useMutation(api.notifications.markAllAsRead);
  const router = useRouter();

  const getIcon = (type: string) => {
    switch (type) {
      case "message": return <MessageSquare size={20} className="text-primary" />;
      case "price_drop": return <TrendingDown size={20} className="text-green-500" />;
      default: return <Info size={20} className="text-blue-500" />;
    }
  };

  const renderNotification = ({ item }: { item: any }) => (
    <Pressable 
      onPress={() => {
        markAsRead({ notificationId: item._id });
        if (item.type === "price_drop" && item.data?.carId) {
          router.push(`/car/${item.data.carId}`);
        } else if (item.type === "message" && item.data?.conversationId) {
          router.push(`/chat/${item.data.conversationId}`);
        }
      }}
      className="mb-3"
    >
      <Card className={`border-border ${item.read ? "bg-card/50 opacity-80" : "bg-card"} overflow-hidden`}>
        <CardContent className="p-4 flex-row gap-4">
          <View className={`h-10 w-10 items-center justify-center rounded-full ${item.read ? "bg-secondary/30" : "bg-secondary/80"}`}>
            {getIcon(item.type)}
          </View>
          
          <View className="flex-1">
            <View className="mb-1 flex-row items-center justify-between">
              <Text className={`font-bold ${item.read ? "text-muted-foreground" : "text-foreground"}`}>
                {item.title}
              </Text>
              {!item.read && <Circle size={8} className="fill-primary text-primary" />}
            </View>
            <Text className="text-sm text-muted-foreground" numberOfLines={2}>
              {item.body}
            </Text>
            <Text className="mt-2 text-[10px] text-muted-foreground">
              {new Date(item.createdAt).toLocaleDateString()} at {new Date(item.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </Text>
          </View>
        </CardContent>
      </Card>
    </Pressable>
  );

  return (
    <SafeAreaView className="flex-1 bg-background" edges={["top"]}>
      <View className="px-4 py-4 flex-row items-center justify-between">
        <View>
          <Text className="text-3xl font-bold text-foreground">Alerts</Text>
          <Text className="text-sm text-muted-foreground">Stay updated on your watchlist</Text>
        </View>
        {notifications && notifications.some(n => !n.read) && (
          <Button 
            variant="ghost" 
            size="sm" 
            className="flex-row gap-1"
            onPress={() => markAllAsRead({ userId: USER_ID })}
          >
            <CheckCircle2 size={16} className="text-muted-foreground" />
            <Text className="text-xs text-muted-foreground font-bold">Mark all as read</Text>
          </Button>
        )}
      </View>
      
      {!notifications || notifications.length === 0 ? (
        <View className="flex-1 items-center justify-center px-6">
          <View className="mb-6 h-20 w-20 items-center justify-center rounded-full bg-secondary">
            <Bell size={40} className="text-muted" />
          </View>
          <Text className="mb-2 text-xl font-bold text-foreground">All caught up!</Text>
          <Text className="text-center text-muted-foreground">
            No new alerts. Save a car to your watchlist to get notified of price drops.
          </Text>
        </View>
      ) : (
        <FlatList
          data={notifications}
          renderItem={renderNotification}
          keyExtractor={(item) => item._id}
          contentContainerStyle={{ padding: 16 }}
          showsVerticalScrollIndicator={false}
        />
      )}
    </SafeAreaView>
  );
}
