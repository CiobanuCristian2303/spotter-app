import { Tabs } from "expo-router";
import { Home, PlusSquare, MessageSquare, User, Bell } from "lucide-react-native";
import { Platform, View } from "react-native";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";

import { HapticTab } from "@/components/HapticTab";
import TabBarBackground from "@/components/ui/TabBarBackground";
import { useColorScheme } from "@/hooks/useColorScheme";
import { Colors } from "@/constants/Colors";

const USER_ID = "mock_user_123";

export default function TabLayout() {
  const colorScheme = useColorScheme();
  const notifications = useQuery(api.notifications.list, { userId: USER_ID });
  const unreadCount = notifications?.filter(n => !n.read).length || 0;

  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: Colors[colorScheme ?? "light"].tint,
        headerShown: false,
        tabBarButton: HapticTab,
        tabBarBackground: TabBarBackground,
        tabBarLabelPosition: "below-icon",
        tabBarLabelStyle: Platform.select({
          web: { overflow: "visible" },
          default: {},
        }),
        tabBarStyle: Platform.select({
          ios: {
            position: "absolute",
            backgroundColor: "#0A111F",
            borderTopColor: "rgba(229, 228, 226, 0.1)",
          },
          default: {
            backgroundColor: "#0A111F",
            borderTopColor: "rgba(229, 228, 226, 0.1)",
          },
        }),
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: "Home",
          tabBarIcon: ({ color }) => <Home size={22} color={color} />,
        }}
      />
      <Tabs.Screen
        name="notifications"
        options={{
          title: "Alerts",
          tabBarIcon: ({ color }) => (
            <View>
              <Bell size={22} color={color} />
              {unreadCount > 0 && (
                <View className="absolute -right-2 -top-1 h-4 w-4 items-center justify-center rounded-full bg-primary">
                  <View className="h-1.5 w-1.5 rounded-full bg-white" />
                </View>
              )}
            </View>
          ),
        }}
      />
      <Tabs.Screen
        name="sell"
        options={{
          title: "Sell",
          tabBarIcon: ({ color }) => <PlusSquare size={22} color={color} />,
        }}
      />
      <Tabs.Screen
        name="messages"
        options={{
          title: "Messages",
          tabBarIcon: ({ color }) => <MessageSquare size={22} color={color} />,
        }}
      />
      <Tabs.Screen
        name="explore"
        options={{
          title: "Profile",
          tabBarIcon: ({ color }) => <User size={22} color={color} />,
        }}
      />
    </Tabs>
  );
}
