import React, { useState } from "react";
import { View, ScrollView, Image, Alert, ActivityIndicator } from "react-native";
import { useForm, Controller } from "react-hook-form";
import * as ImagePicker from "expo-image-picker";
import { useMutation, useAction, useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import {
  Text,
  Input,
  Button,
  SafeAreaView,
  Card,
  CardContent,
  Pressable,
  Badge,
  Label,
} from "@/components/ui";
import {
  Plus,
  Trash2,
  ChevronRight,
  ChevronLeft,
  Check,
  Sparkles,
  Zap,
  Link as LinkIcon,
} from "lucide-react-native";
import { useRouter } from "expo-router";
import { Logo } from "@/components/Logo";

type FormData = {
  make: string;
  model: string;
  year: number;
  vin: string;
  mileage: number;
  engineSize: number;
  hp: number;
  fuelType: string;
  transmission: string;
  price: number;
  location: string;
  description: string;
  sellerType: "private" | "dealer";
};

// Mock Cloudinary implementation for the flow
const CLOUD_NAME = process.env.EXPO_PUBLIC_CLOUDINARY_CLOUD_NAME || "spotter-ro";
const simulateAIProcessing = async (uri: string, isStudio: boolean) => {
  await new Promise(resolve => setTimeout(resolve, 2000));
  if (!isStudio) return uri;
  return `https://res.cloudinary.com/${CLOUD_NAME}/image/upload/e_background_removal,c_pad,h_800,w_1200,b_rgb:0A111F/v1/cars/sample_id`;
};

export default function SellScreen() {
  const [step, setStep] = useState(1);
  const [images, setImages] = useState<{ uri: string; studio: boolean }[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [importUrl, setImportUrl] = useState("");
  const [uploadProgress, setUploadProgress] = useState(0);
  
  const router = useRouter();
  const createListing = useMutation(api.cars.createNativeListing);
  const importFromUrl = useAction((api as any).ai.importFromUrl);
  const me = useQuery(api.users.me);

  const { control, handleSubmit, setValue, formState: { errors } } = useForm<FormData>({
    defaultValues: {
      make: "",
      model: "",
      year: 2024,
      vin: "",
      mileage: 0,
      engineSize: 1998,
      hp: 150,
      fuelType: "Petrol",
      transmission: "Automatic",
      price: 0,
      location: "",
      description: "",
      sellerType: "private",
    }
  });

  const handleMagicImport = async () => {
    if (!importUrl) return;
    setIsImporting(true);
    try {
      const data = await importFromUrl({ url: importUrl });
      if (data) {
        if (data.make) setValue("make", data.make);
        if (data.model) setValue("model", data.model);
        if (data.year) setValue("year", parseInt(data.year) || 2024);
        if (data.price) setValue("price", parseInt(data.price) || 0);
        if (data.mileage) setValue("mileage", parseInt(data.mileage) || 0);
        if (data.hp) setValue("hp", parseInt(data.hp) || 0);
        if (data.fuelType) setValue("fuelType", data.fuelType);
        if (data.transmission) setValue("transmission", data.transmission);
        if (data.location) setValue("location", data.location);
        if (data.description) setValue("description", data.description);
        if (data.vin) setValue("vin", data.vin);
        if (data.engineSize) setValue("engineSize", parseInt(data.engineSize) || 0);
        
        Alert.alert("Magic Success!", "We've populated the form using AI. Please review the details.");
      }
    } catch (error) {
      Alert.alert("Import Failed", "Could not extract data from this link. Make sure it's a valid car listing.");
    } finally {
      setIsImporting(false);
    }
  };

  const pickImage = async () => {
    if (images.length >= 10) {
      Alert.alert("Limit Reached", "You can only upload up to 10 images.");
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      allowsMultipleSelection: true,
      selectionLimit: 10 - images.length,
      quality: 0.8,
    });

    if (!result.canceled) {
      const newImages = result.assets.map(asset => ({ uri: asset.uri, studio: false }));
      setImages([...images, ...newImages]);
    }
  };

  const removeImage = (index: number) => {
    setImages(images.filter((_, i) => i !== index));
  };

  const toggleStudio = (index: number) => {
    const newImages = [...images];
    newImages[index].studio = !newImages[index].studio;
    setImages(newImages);
  };

  const onSubmit = async (data: FormData) => {
    if (images.length === 0) {
      Alert.alert("Error", "Please add at least one photo.");
      return;
    }

    setIsUploading(true);
    setUploadProgress(10);
    
    try {
      const processedUrls = [];
      for (let i = 0; i < images.length; i++) {
        setUploadProgress(10 + Math.floor((i / images.length) * 80));
        const url = await simulateAIProcessing(images[i].uri, images[i].studio);
        processedUrls.push(url);
      }
      
      setUploadProgress(95);

      await createListing({
        ...data,
        images: processedUrls,
        currency: "EUR",
      });

      setUploadProgress(100);
      Alert.alert("Success", "Professional Ad published with AI Studio Mode!", [
        { text: "View Dashboard", onPress: () => router.replace("/(tabs)/explore") }
      ]);
    } catch (error) {
      Alert.alert("Error", "Failed to process listing.");
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
    }
  };

  const nextStep = () => setStep(s => s + 1);
  const prevStep = () => setStep(s => s - 1);

  const renderProgress = () => (
    <View className="mb-8 flex-row gap-2 px-6">
      {[1, 2, 3].map((s) => (
        <View 
          key={s} 
          className={`h-1.5 flex-1 rounded-full ${s <= step ? "bg-cerulean shadow-[0_0_8px_rgba(0,123,167,0.5)]" : "bg-platinum/10"}`} 
        />
      ))}
    </View>
  );

  return (
    <SafeAreaView className="flex-1 bg-navy" edges={["top"]}>
      <View className="px-6 py-5 flex-row justify-between items-center mb-2">
        <View>
           <Text className="text-3xl font-bold text-platinum tracking-tight">Create Listing</Text>
           <Text className="text-xs text-muted-foreground uppercase tracking-widest font-bold mt-1">Configuration Step {step} of 3</Text>
        </View>
        <Badge variant="gold" className="h-8 px-3">
           <Zap size={12} className="text-white mr-1.5" />
           <Text className="text-[10px] text-white font-bold tracking-widest">ELITE</Text>
        </Badge>
      </View>

      {renderProgress()}

      <ScrollView className="flex-1 px-6" showsVerticalScrollIndicator={false}>
        {step === 1 && (
          <View className="gap-8 py-4">
            <Card className="border-cerulean/20 bg-cerulean/5 shadow-2xl">
              <CardContent className="p-6">
                  <View className="flex-row items-center gap-4 mb-5">
                    <View className="h-10 w-10 rounded-2xl bg-cerulean/10 items-center justify-center border border-cerulean/20">
                        <Sparkles size={20} className="text-cerulean stroke-[1.5]" />
                    </View>
                    <View>
                        <Text className="font-bold text-platinum text-lg">AI Magic Importer</Text>
                        <Text className="text-[10px] text-muted-foreground uppercase tracking-widest font-bold">Auto-sync from URL</Text>
                    </View>
                  </View>
                  <View className="flex-row gap-3">
                    <Input 
                        placeholder="Paste Autovit/OLX link..." 
                        className="flex-1 h-12 bg-platinum/5 border-platinum/10 text-platinum rounded-xl"
                        value={importUrl}
                        onChangeText={setImportUrl}
                    />
                    <Button 
                        size="sm" 
                        variant="platinum"
                        className="h-12 px-6"
                        onPress={handleMagicImport}
                        disabled={isImporting}
                    >
                        {isImporting ? <ActivityIndicator size="small" color="#0A111F" /> : <Text>IMPORT</Text>}
                    </Button>
                  </View>
              </CardContent>
            </Card>

            <View>
              <View className="flex-row justify-between items-center mb-5 px-1">
                <Text className="text-xl font-bold text-platinum tracking-tight">Media Gallery</Text>
                <View className="flex-row items-center gap-1.5 bg-gold/10 px-3 py-1 rounded-full border border-gold/20">
                   <Sparkles size={12} className="text-gold" />
                   <Text className="text-[10px] font-bold text-gold uppercase">Studio Mode</Text>
                </View>
              </View>
              
              <ScrollView horizontal showsHorizontalScrollIndicator={false} className="-mx-6 px-6">
                <View className="flex-row gap-4">
                  <Pressable 
                    onPress={pickImage}
                    className="h-44 w-44 items-center justify-center rounded-[32px] border-2 border-dashed border-platinum/20 bg-platinum/5"
                  >
                    <Plus size={36} className="text-cerulean stroke-[1.5]" />
                    <Text className="mt-3 text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Add Assets</Text>
                  </Pressable>
                  {images.map((img, idx) => (
                    <View key={idx} className="relative h-44 w-44 overflow-hidden rounded-[32px] border border-platinum/10 shadow-2xl bg-navy">
                      <Image source={{ uri: img.uri }} className="h-full w-full" />
                      <Pressable 
                        onPress={() => removeImage(idx)}
                        className="absolute right-3 top-3 rounded-full bg-navy/80 p-2 border border-platinum/10"
                      >
                        <Trash2 size={16} className="text-destructive" />
                      </Pressable>
                      <Pressable 
                        onPress={() => toggleStudio(idx)}
                        className={`absolute bottom-3 left-3 right-3 flex-row items-center justify-center gap-2 rounded-2xl py-2.5 border ${img.studio ? "bg-cerulean border-cerulean" : "bg-navy/80 border-platinum/20"}`}
                      >
                        <Sparkles size={14} className="text-white" />
                        <Text className="text-[10px] font-bold text-white uppercase tracking-widest">{img.studio ? "Studio Active" : "Studio Off"}</Text>
                      </Pressable>
                    </View>
                  ))}
                </View>
              </ScrollView>
            </View>

            <View className="gap-5">
              <Text className="text-xl font-bold text-platinum tracking-tight px-1">Vehicle Specifications</Text>
              <View className="gap-5">
                <View className="gap-2">
                  <Label className="text-platinum/60 font-bold uppercase text-[10px] tracking-[2px] ml-1">Make</Label>
                  <Controller
                    control={control}
                    name="make"
                    rules={{ required: true }}
                    render={({ field: { onChange, value } }) => (
                      <Input placeholder="Enter manufacturer..." value={value} onChangeText={onChange} className="bg-platinum/5 border-platinum/10 text-platinum h-14 rounded-2xl" />
                    )}
                  />
                </View>
                <View className="gap-2">
                  <Label className="text-platinum/60 font-bold uppercase text-[10px] tracking-[2px] ml-1">Model</Label>
                  <Controller
                    control={control}
                    name="model"
                    rules={{ required: true }}
                    render={({ field: { onChange, value } }) => (
                      <Input placeholder="Enter model name..." value={value} onChangeText={onChange} className="bg-platinum/5 border-platinum/10 text-platinum h-14 rounded-2xl" />
                    )}
                  />
                </View>
              </View>
            </View>
          </View>
        )}

        {step === 2 && (
          <View className="gap-6 py-4">
            <Text className="text-xl font-bold text-platinum tracking-tight px-1">Technical Parameters</Text>
            
            <View className="flex-row gap-4">
              <View className="flex-1 gap-2">
                <Label className="text-platinum/60 font-bold uppercase text-[10px] tracking-[2px] ml-1">Year</Label>
                <Controller
                  control={control}
                  name="year"
                  render={({ field: { onChange, value } }) => (
                    <Input placeholder="2024" keyboardType="numeric" value={value?.toString()} onChangeText={v => onChange(parseInt(v))} className="bg-platinum/5 border-platinum/10 text-platinum h-14 rounded-2xl" />
                  )}
                />
              </View>
              <View className="flex-1 gap-2">
                <Label className="text-platinum/60 font-bold uppercase text-[10px] tracking-[2px] ml-1">Mileage (KM)</Label>
                <Controller
                  control={control}
                  name="mileage"
                  render={({ field: { onChange, value } }) => (
                    <Input placeholder="0" keyboardType="numeric" value={value?.toString()} onChangeText={v => onChange(parseInt(v))} className="bg-platinum/5 border-platinum/10 text-platinum h-14 rounded-2xl" />
                  )}
                />
              </View>
            </View>

            <View className="gap-2">
              <Label className="text-platinum/60 font-bold uppercase text-[10px] tracking-[2px] ml-1">VIN Number (Recommended)</Label>
              <Controller
                control={control}
                name="vin"
                render={({ field: { onChange, value } }) => (
                  <Input placeholder="17-digit identification code" value={value} onChangeText={onChange} className="bg-platinum/5 border-platinum/10 text-platinum h-14 rounded-2xl uppercase font-mono" />
                )}
              />
              <Text className="text-[10px] text-cerulean font-bold uppercase tracking-widest mt-1 ml-1">Unlocks CarVertical Badge</Text>
            </View>

            <View className="flex-row gap-4">
              <View className="flex-1 gap-2">
                <Label className="text-platinum/60 font-bold uppercase text-[10px] tracking-[2px] ml-1">Fuel</Label>
                <Controller
                  control={control}
                  name="fuelType"
                  render={({ field: { onChange, value } }) => (
                    <View className="flex-row gap-2 flex-wrap">
                      {["Petrol", "Diesel", "Hybrid", "Electric"].map(f => (
                        <Pressable key={f} onPress={() => onChange(f)}>
                          <Badge variant={value === f ? "platinum" : "outline"} className="px-4 py-2.5 rounded-xl">
                            <Text>{f}</Text>
                          </Badge>
                        </Pressable>
                      ))}
                    </View>
                  )}
                />
              </View>
            </View>

            <View className="gap-2 mt-4">
               <Label className="text-platinum/60 font-bold uppercase text-[10px] tracking-[2px] ml-1">Engine Power (CP)</Label>
               <Controller
                control={control}
                name="hp"
                render={({ field: { onChange, value } }) => (
                  <Input placeholder="150" keyboardType="numeric" value={value?.toString()} onChangeText={v => onChange(parseInt(v))} className="bg-platinum/5 border-platinum/10 text-platinum h-14 rounded-2xl" />
                )}
              />
            </View>
          </View>
        )}

        {step === 3 && (
          <View className="gap-6 py-4">
            <Text className="text-xl font-bold text-platinum tracking-tight px-1">Valuation & Location</Text>
            
            <View className="gap-2">
              <Label className="text-platinum/60 font-bold uppercase text-[10px] tracking-[2px] ml-1">Price (EUR)</Label>
              <Controller
                control={control}
                name="price"
                render={({ field: { onChange, value } }) => (
                  <Input placeholder="0.00" keyboardType="numeric" value={value?.toString()} onChangeText={v => onChange(parseInt(v))} className="bg-platinum/5 border-platinum/10 text-cerulean text-2xl font-bold h-16 rounded-2xl" />
                )}
              />
            </View>

            <View className="gap-2">
              <Label className="text-platinum/60 font-bold uppercase text-[10px] tracking-[2px] ml-1">City / Region</Label>
              <Controller
                control={control}
                name="location"
                render={({ field: { onChange, value } }) => (
                  <Input placeholder="e.g. Bucharest" value={value} onChangeText={onChange} className="bg-platinum/5 border-platinum/10 text-platinum h-14 rounded-2xl" />
                )}
              />
            </View>

            <View className="gap-2">
              <Label className="text-platinum/60 font-bold uppercase text-[10px] tracking-[2px] ml-1">Listing Narrative</Label>
              <Controller
                control={control}
                name="description"
                render={({ field: { onChange, value } }) => (
                  <Input 
                    placeholder="Describe vehicle condition, features, history..." 
                    value={value} 
                    onChangeText={onChange} 
                    multiline 
                    numberOfLines={6}
                    className="bg-platinum/5 border-platinum/10 text-platinum min-h-[150px] rounded-2xl p-4 text-sm"
                    style={{ textAlignVertical: "top" }}
                  />
                )}
              />
            </View>
          </View>
        )}
      </ScrollView>

      <View className="p-6 border-t border-platinum/10 bg-navy/90 backdrop-blur-xl flex-row gap-4 mb-6">
        {step > 1 && (
          <Button 
            variant="outline" 
            className="flex-1 h-16 border-platinum/10"
            onPress={prevStep}
            disabled={isUploading}
          >
            <ChevronLeft size={24} className="text-platinum" />
          </Button>
        )}
        
        {step < 3 ? (
          <Button 
            className="flex-[2] h-16 shadow-lg shadow-cerulean/30"
            onPress={nextStep}
          >
            <Text className="font-bold text-white uppercase tracking-widest text-sm">Continue</Text>
            <ChevronRight size={20} className="text-white ml-2" />
          </Button>
        ) : (
          <Button 
            className="flex-[2] h-16 shadow-lg shadow-cerulean/30"
            onPress={handleSubmit(onSubmit)}
            disabled={isUploading}
          >
            {isUploading ? (
              <View className="items-center">
                 <ActivityIndicator color="white" />
                 <Text className="text-[10px] text-white/70 mt-1 uppercase font-bold">{uploadProgress}% Processing</Text>
              </View>
            ) : (
              <>
                <Text className="font-bold text-white uppercase tracking-widest text-sm">Publish Ad</Text>
                <Check size={20} className="text-white ml-2" />
              </>
            )}
          </Button>
        )}
      </View>
    </SafeAreaView>
  );
}
