import React from "react";
import { View, FlatList, Image } from "react-native";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Text, SafeAreaView, Pressable, Card, Badge } from "@/components/ui";
import { MessageSquare, ChevronRight, Clock } from "lucide-react-native";
import { useRouter } from "expo-router";

const MOCK_USER_ID = "user_123";

export default function MessagesScreen() {
  const conversations = useQuery(api.messages.getConversations, { userId: MOCK_USER_ID });
  const router = useRouter();

  const formatTime = (timestamp: number) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const renderConversation = ({ item }: { item: any }) => (
    <Pressable 
      onPress={() => router.push(`/chat/${item._id}`)}
      className="mb-3"
    >
      <Card className="border-border bg-card overflow-hidden">
        <View className="flex-row p-4">
          <View className="relative">
            <Image 
              source={{ uri: item.car?.images[0] }} 
              className="h-16 w-16 rounded-lg bg-secondary"
            />
            <View className="absolute -bottom-1 -right-1 h-4 w-4 rounded-full border-2 border-card bg-green-500" />
          </View>
          
          <View className="ml-4 flex-1 justify-center">
            <View className="mb-1 flex-row items-center justify-between">
              <Text className="font-bold text-foreground">
                {item.car?.make} {item.car?.model}
              </Text>
              <Text className="text-[10px] text-muted-foreground">
                {formatTime(item.lastMessageAt)}
              </Text>
            </View>
            
            <Text 
              className="text-sm text-muted-foreground" 
              numberOfLines={1}
            >
              {item.lastMessageText || "Start a conversation..."}
            </Text>
          </View>
          
          <View className="ml-2 justify-center">
            <ChevronRight size={18} className="text-muted-foreground" />
          </View>
        </View>
      </Card>
    </Pressable>
  );

  return (
    <SafeAreaView className="flex-1 bg-background" edges={["top"]}>
      <View className="px-4 py-4">
        <Text className="text-3xl font-bold text-foreground">Messages</Text>
        <Text className="text-sm text-muted-foreground">Your active inquiries</Text>
      </View>
      
      {!conversations || conversations.length === 0 ? (
        <View className="flex-1 items-center justify-center px-6">
          <View className="mb-6 h-20 w-20 items-center justify-center rounded-full bg-secondary">
            <MessageSquare size={40} className="text-muted" />
          </View>
          <Text className="mb-2 text-xl font-bold text-foreground">No messages yet</Text>
          <Text className="text-center text-muted-foreground">
            Your conversations with sellers will appear here. Find a car you like and send a message!
          </Text>
        </View>
      ) : (
        <FlatList
          data={conversations}
          renderItem={renderConversation}
          keyExtractor={(item) => item._id}
          contentContainerStyle={{ padding: 16 }}
          showsVerticalScrollIndicator={false}
        />
      )}
    </SafeAreaView>
  );
}
