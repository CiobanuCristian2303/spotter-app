import React, { useState } from "react";
import { View, ScrollView, Linking, ActivityIndicator, Pressable } from "react-native";
import { Image } from "expo-image";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import {
  Text,
  Button,
  SafeAreaView,
  Badge,
  Card,
  CardContent,
} from "@/components/ui";
import {
  ChevronLeft,
  Share2,
  Heart,
  MapPin,
  Calendar,
  Gauge,
  ExternalLink,
  MessageCircle,
  ShieldCheck,
  TrendingDown,
  User,
  ShieldCheck as VerifiedIcon,
  Star,
} from "lucide-react-native";
import { Logo } from "@/components/Logo";

const USER_ID = "mock_user_123";

export default function CarDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const [isStartingChat, setIsStartingChat] = useState(false);
  
  const car = useQuery(api.cars.getById, { id: id as Id<"cars"> });
  const seller = useQuery(api.users.getSellerProfile, car?.userId ? { userId: car.userId } : "skip" as any) as any;
  const watchlist = useQuery(api.cars.getWatchlist, { userId: USER_ID });
  const toggleWatchlist = useMutation(api.cars.toggleWatchlist);
  const me = useQuery(api.users.me);
  const getOrCreateConv = useMutation(api.messages.getOrCreateConversation);
  const incrementLeads = useMutation(api.cars.incrementLeads);

  const isWatched = watchlist?.some(w => w._id === id);

  const handleMessageSeller = async () => {
    if (!car) return;
    setIsStartingChat(true);
    try {
      await incrementLeads({ id: car._id });

      const sellerId = car.userId || USER_ID;
      
      const convId = await getOrCreateConv({
        carId: car._id,
        sellerId: sellerId as any,
        buyerId: (me?._id || USER_ID) as any,
      });
      
      router.push(`/chat/${convId}`);
    } catch (error) {
      console.error("Error starting chat:", error);
    } finally {
      setIsStartingChat(false);
    }
  };

  if (!car) {
    return (
      <SafeAreaView className="flex-1 bg-navy items-center justify-center">
        <ActivityIndicator color="#007BA7" />
      </SafeAreaView>
    );
  }

  const bestPrice = Math.min(...car.sources.map(s => s.price));
  const otherSources = car.sources.sort((a, b) => a.price - b.price);

  return (
    <View className="flex-1 bg-navy">
      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        <View className="relative">
          <Image
            source={{ uri: car.images[0] }}
            className="h-[450px] w-full"
            resizeMode="cover"
          />
          <SafeAreaView className="absolute left-4 top-4 flex-row gap-2" edges={["top"]}>
            <Button
              variant="ghost"
              size="icon"
              className="rounded-full bg-navy/60 border border-platinum/10 backdrop-blur-md"
              onPress={() => router.back()}
            >
              <ChevronLeft size={24} className="text-platinum" />
            </Button>
          </SafeAreaView>
          <SafeAreaView className="absolute right-4 top-4 flex-row gap-2" edges={["top"]}>
            <Button
              variant="ghost"
              size="icon"
              className="rounded-full bg-navy/60 border border-platinum/10 backdrop-blur-md"
            >
              <Share2 size={20} className="text-platinum" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="rounded-full bg-navy/60 border border-platinum/10 backdrop-blur-md"
              onPress={() => toggleWatchlist({ userId: USER_ID, carId: car._id })}
            >
              <Heart 
                size={20} 
                className={isWatched ? "fill-cerulean text-cerulean" : "text-platinum"} 
              />
            </Button>
          </SafeAreaView>
        </View>

        <View className="px-6 py-6 -mt-8 bg-navy rounded-t-[40px] border-t border-platinum/10 shadow-2xl">
          <View className="mb-3 flex-row items-center justify-between">
            <Text className="text-3xl font-bold text-platinum tracking-tighter">
              {car.make} {car.model}
            </Text>
            <View className="flex-row gap-1">
              {car.sources.map((s, idx) => (
                <Badge key={idx} variant={s.platform === "Spotter" ? "gold" : "outline"} className="h-6">
                  <Text className="text-[8px] font-bold uppercase">{s.platform}</Text>
                </Badge>
              ))}
            </View>
          </View>

          <View className="mb-6 flex-row items-baseline gap-2">
            <Text className="text-3xl font-bold text-cerulean">
              {bestPrice.toLocaleString()} {car.currency}
            </Text>
            {car.previousPrice && car.previousPrice > car.price && (
              <Badge variant="outline" className="bg-emerald-500/10 border-emerald-500/20 px-2">
                <TrendingDown size={12} className="mr-1 text-emerald-400" />
                <Text className="text-[10px] font-bold text-emerald-400 uppercase">Price drop!</Text>
              </Badge>
            )}
          </View>

          {/* Seller Card */}
          <Card className="mb-8 border-platinum/10 bg-navy/40">
            <CardContent className="p-5 flex-row items-center justify-between">
              <View className="flex-row items-center gap-4">
                <View className="h-14 w-14 items-center justify-center rounded-2xl bg-platinum/5 border border-platinum/10 shadow-inner">
                  {seller?.image ? (
                    <Image source={{ uri: seller.image }} className="h-full w-full rounded-2xl" />
                  ) : (
                    <User size={28} className="text-platinum/40" />
                  )}
                </View>
                <View>
                  <View className="flex-row items-center gap-2">
                    <Text className="text-lg font-bold text-platinum tracking-tight">
                      {seller?.role === "DEALER" ? seller.companyName : (seller?.name || "Spotter User")}
                    </Text>
                    {seller?.role === "DEALER" && (
                       <VerifiedIcon size={16} className="text-cerulean" />
                    )}
                  </View>
                  {seller?.role === "DEALER" && seller.rating && (
                    <View className="flex-row items-center gap-1.5 mt-1">
                       <View className="flex-row items-center gap-0.5 bg-gold/10 px-2 py-0.5 rounded-full border border-gold/20">
                          <Star size={10} className="fill-gold text-gold" />
                          <Text className="text-[10px] font-bold text-gold">{seller.rating}</Text>
                       </View>
                       <Text className="text-[10px] text-muted-foreground font-medium">({seller.reviewCount} reviews)</Text>
                       {seller.rating >= 4.5 && (
                          <Badge variant="gold" className="h-4 px-1.5 border-0">
                             <Text className="text-[7px] font-bold text-white uppercase tracking-wider">Elite Partner</Text>
                          </Badge>
                       )}
                    </View>
                  )}
                  <Text className="text-xs text-muted-foreground mt-1 font-medium">
                    {seller?.role || "PRIVATE"} • Member since {seller ? new Date(seller._creationTime).getFullYear() : "2024"}
                  </Text>
                </View>
              </View>
            </CardContent>
          </Card>

          {car.sources.length > 1 && (
            <Card className="mb-8 border-emerald-500/20 bg-emerald-500/5">
              <CardContent className="p-5">
                <Text className="mb-4 font-bold text-platinum text-lg tracking-tight">Best Price Discovery</Text>
                <View className="gap-4">
                  {otherSources.map((source, idx) => (
                    <View key={idx} className="flex-row items-center justify-between">
                      <View className="flex-row items-center gap-2">
                        <Text className="font-semibold text-platinum/80">{source.platform}</Text>
                        {idx === 0 && (
                           <Badge variant="gold" className="h-4 px-1.5">
                             <Text className="text-[7px] font-bold text-white uppercase">Best</Text>
                           </Badge>
                        )}
                      </View>
                      <View className="flex-row items-center gap-3">
                        <Text className={`font-bold text-lg ${idx === 0 ? "text-emerald-400" : "text-platinum"}`}>
                          {source.price.toLocaleString()} {car.currency}
                        </Text>
                        {source.url && (
                          <Pressable onPress={() => Linking.openURL(source.url!)} className="h-8 w-8 items-center justify-center rounded-full bg-platinum/10">
                            <ExternalLink size={16} className="text-cerulean" />
                          </Pressable>
                        )}
                      </View>
                    </View>
                  ))}
                </View>
              </CardContent>
            </Card>
          )}

          <View className="mb-8 flex-row items-center gap-4">
            <View className="flex-1 rounded-[24px] bg-platinum/5 p-4 border border-platinum/5">
              <Calendar size={22} className="mb-2 text-cerulean stroke-[1.5]" />
              <Text className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest">Year</Text>
              <Text className="text-lg font-bold text-platinum">{car.year}</Text>
            </View>
            <View className="flex-1 rounded-[24px] bg-platinum/5 p-4 border border-platinum/5">
              <Gauge size={22} className="mb-2 text-cerulean stroke-[1.5]" />
              <Text className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest">Mileage</Text>
              <Text className="text-lg font-bold text-platinum">{car.mileage.toLocaleString()} km</Text>
            </View>
            <View className="flex-1 rounded-[24px] bg-platinum/5 p-4 border border-platinum/5">
              <MapPin size={22} className="mb-2 text-cerulean stroke-[1.5]" />
              <Text className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest">Location</Text>
              <Text className="text-lg font-bold text-platinum" numberOfLines={1}>{car.location}</Text>
            </View>
          </View>

          <Card className="mb-8 border-platinum/10 bg-navy/20">
            <CardContent className="p-6">
              <Text className="mb-5 text-xl font-bold text-platinum tracking-tight">Vehicle Specifications</Text>
              <View className="gap-4">
                <View className="flex-row justify-between items-center">
                  <Text className="text-muted-foreground font-medium text-sm uppercase tracking-wider text-[10px]">Fuel Type</Text>
                  <Text className="font-bold text-platinum">{car.fuelType || "N/A"}</Text>
                </View>
                <View className="flex-row justify-between items-center border-t border-platinum/5 pt-4">
                  <Text className="text-muted-foreground font-medium text-sm uppercase tracking-wider text-[10px]">Transmission</Text>
                  <Text className="font-bold text-platinum">{car.transmission || "N/A"}</Text>
                </View>
                <View className="flex-row justify-between items-center border-t border-platinum/5 pt-4">
                  <Text className="text-muted-foreground font-medium text-sm uppercase tracking-wider text-[10px]">Engine Size</Text>
                  <Text className="font-bold text-platinum">{car.engineSize ? `${car.engineSize} cm³` : "N/A"}</Text>
                </View>
                <View className="flex-row justify-between items-center border-t border-platinum/5 pt-4">
                  <Text className="text-muted-foreground font-medium text-sm uppercase tracking-wider text-[10px]">Performance</Text>
                  <Text className="font-bold text-platinum">{car.hp ? `${car.hp} HP` : "N/A"}</Text>
                </View>
                {car.vin && (
                   <View className="flex-row justify-between items-center border-t border-cerulean/20 mt-2 pt-4">
                   <Text className="text-cerulean font-bold uppercase tracking-wider text-[10px]">VIN Identifier</Text>
                   <Text className="font-bold text-platinum select-text">{car.vin}</Text>
                 </View>
                )}
              </View>
            </CardContent>
          </Card>

          <Text className="mb-3 text-xl font-bold text-platinum tracking-tight px-1">Description</Text>
          <Text className="mb-8 leading-7 text-muted-foreground font-medium px-1">
            {car.description}
          </Text>

          {car.vin && (
            <Button
              variant="default"
              className="mb-10 w-full flex-row gap-3 h-16 bg-[#0052FF]"
              onPress={() => Linking.openURL(`https://www.carvertical.com/ro/verificare-vin?vin=${car.vin}&a=spotter_ro`)}
            >
              <ShieldCheck size={24} className="text-white stroke-[1.5]" />
              <View>
                 <Text className="font-bold text-white uppercase text-xs tracking-widest">Verify with CarVertical</Text>
                 <Text className="text-[10px] text-white/70">Secure vehicle history report</Text>
              </View>
            </Button>
          )}
        </View>
      </ScrollView>

      <View className="border-t border-platinum/10 bg-navy/90 backdrop-blur-xl p-6 pb-12 flex-row gap-3">
        <Button 
          className="flex-[2] flex-row gap-2 h-14"
          onPress={handleMessageSeller}
          disabled={isStartingChat}
        >
          {isStartingChat ? (
            <ActivityIndicator color="white" />
          ) : (
            <>
              <MessageCircle size={20} className="text-white" />
              <Text className="font-bold text-white uppercase text-xs tracking-widest">Message Seller</Text>
            </>
          )}
        </Button>
        {!car.isNative && (
          <Button 
            variant="outline" 
            className="flex-1 h-14 border-platinum/20"
            onPress={() => car.sources[0].url && Linking.openURL(car.sources[0].url)}
          >
            <ExternalLink size={20} className="text-platinum" />
          </Button>
        )}
      </View>
    </View>
  );
}
